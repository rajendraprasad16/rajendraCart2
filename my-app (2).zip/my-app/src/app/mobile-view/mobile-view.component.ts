import { Component, OnInit , Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FilterDialogComponent } from '../filter-dialog/filter-dialog.component';


export interface DialogData {
  animal: string;
  name: string;
}


@Component({
  selector: 'app-mobile-view',
  templateUrl: './mobile-view.component.html',
  styleUrls: ['./mobile-view.component.scss']
})
export class MobileViewComponent implements OnInit {

  isDialogOpened : false;
    "items"= [
       {
          "name":"Samsung Series 4",
          "image":"https://rukminim1.flixcart.com/image/670/600/allinone-desktop/d/n/q/apple-imac-21-5-inch-4k-retina-core-i5-3-1ghz-8gb-1tb-intel-iris-original-imaeh5h83fuzbksz.jpeg?q=90",
          "price":{
             "actual":13999,
             "display":22500
          },
          "discount":37
       },
       {
          "name":"Samsung Super 6",
          "image":"https://rukminim1.flixcart.com/image/670/600/allinone-desktop/d/n/q/apple-imac-21-5-inch-4k-retina-core-i5-3-1ghz-8gb-1tb-intel-iris-original-imaeh5h83fuzbksz.jpeg?q=90",
          "price":{
             "actual":35999,
             "display":66900
          },
          "discount":46
       },
       {
          "name":"Samsung The Frame",
          "image":"https://rukminim1.flixcart.com/image/670/600/allinone-desktop/d/n/q/apple-imac-21-5-inch-4k-retina-core-i5-3-1ghz-8gb-1tb-intel-iris-original-imaeh5h83fuzbksz.jpeg?q=90",
          "price":{
             "actual":84999,
             "display":133900
          },
          "discount":36
       },
       {
          "name":"Thomson B9 Pro",
          "image":"https://rukminim1.flixcart.com/image/670/600/allinone-desktop/d/n/q/apple-imac-21-5-inch-4k-retina-core-i5-3-1ghz-8gb-1tb-intel-iris-original-imaeh5h83fuzbksz.jpeg?q=90",
          "price":{
             "actual":9999,
             "display":16999
          },
          "discount":41
       },
       {
          "name":"LG Ultra HD",
          "image":"https://rukminim1.flixcart.com/image/670/600/allinone-desktop/d/n/q/apple-imac-21-5-inch-4k-retina-core-i5-3-1ghz-8gb-1tb-intel-iris-original-imaeh5h83fuzbksz.jpeg?q=90",
          "price":{
             "actual":39990,
             "display":79990
          },
          "discount":50
       },
       {
          "name":"Vu Ready LED TV",
          "image":"https://rukminim1.flixcart.com/image/670/600/allinone-desktop/d/n/q/apple-imac-21-5-inch-4k-retina-core-i5-3-1ghz-8gb-1tb-intel-iris-original-imaeh5h83fuzbksz.jpeg?q=90",
          "price":{
             "actual":7999,
             "display":17e3
          },
          "discount":52
       },
       {
          "name":"Koryo Android TV",
          "image":"https://rukminim1.flixcart.com/image/670/600/allinone-desktop/d/n/q/apple-imac-21-5-inch-4k-retina-core-i5-3-1ghz-8gb-1tb-intel-iris-original-imaeh5h83fuzbksz.jpeg?q=90",
          "price":{
             "actual":55999,
             "display":199990
          },
          "discount":71
       },
       {
          "name":"Micromax LED Smart",
          "image":"https://rukminim1.flixcart.com/image/670/600/allinone-desktop/d/n/q/apple-imac-21-5-inch-4k-retina-core-i5-3-1ghz-8gb-1tb-intel-iris-original-imaeh5h83fuzbksz.jpeg?q=90",
          "price":{
             "actual":9999,
             "display":27990
          },
          "discount":64
       }
    ]
  animal: any;
  name: any;
  count : number = 0;
  defaultItems : boolean = true;
  itemspage : boolean = false
  showbottomheader : boolean = true;


  constructor(public dialog : MatDialog) { }

  
  openDialog(): void {
    const dialogRef = this.dialog.open(SortDialog, {
     
      data: {}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
    });
  }
  
  public incrementbyOne() {
   
    return this.count = this.count + 1;
     
   }

   public itemsPage(){
      this.defaultItems = false;
      this.itemspage = true;
      this.showbottomheader = false;
   }

   openFilter():void {
      const dialogRef = this.dialog.open(FilterDialogComponent, {
       
        data: {}
      });
      dialogRef.afterClosed().subscribe(result => {
         console.log('The dialog was closed');
         this.animal = result;
       });
   }

  ngOnInit() {
  }

  

}


@Component({
  selector: 'app-sort-dialog',
  templateUrl: './sort-dialog.html',
})
export class SortDialog {

  constructor(
    public dialogRef: MatDialogRef<SortDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
  

}


